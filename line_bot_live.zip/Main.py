import os
import time


class Main:
    def __init__(self):
        pass

    def Weboscket_Server(self):
        email_input = self.Driver.find_element_by_css_selector("#line_login_email") email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")
        email_input = self.Driver.find_element_by_css_selector("#line_login_email")

    def Start(self):

        pass

        self.Driver.get("chrome-extension://ophjlpahpchlmihnnnihgmmeilfjmjjc/index.html")






if __name__ == '__main__':
    obj = Main()
    obj.Start()